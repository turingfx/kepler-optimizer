#!/bin/bash
# =============================================================================
# kepler_simply_opt_simple.sh - 简化版 Kepler 优化脚本
# =============================================================================
# 
# 黄金法则 (必须严格遵守):
# 1. kepler.worker.size = parallelismConfig 所有算子值 = Partition 数量 (三者必须一致)
# 2. job.worker.thread.number = 1
# 3. topology.master.worker.memory.size 范围：2G~6G (2147483648 ~ 6442450944)
# 4. kepler.output.odps.buffer.size 范围：60~200
# =============================================================================

TOPOLOGY_ID=$1
COOKIE_FILE="./cookie.txt"
KEPLER_API="https://kepler.alipay.com/api"

if [ -z "$TOPOLOGY_ID" ]; then
    echo "用法: $0 <topologyId>"
    exit 1
fi

COOKIE=$(cat "$COOKIE_FILE")

echo "╔══════════════════════════════════════════════════════════╗"
echo "║     Kepler Simply-Opt 优化 - 任务 $TOPOLOGY_ID                    ║"
echo "╚══════════════════════════════════════════════════════════╝"

# 步骤 1: 获取任务配置
echo "[1/5] 获取任务配置..."
CONFIG=$(curl -s -X GET "${KEPLER_API}/sql/${TOPOLOGY_ID}" -b "$COOKIE" --connect-timeout 10)
TASK_NAME=$(echo "$CONFIG" | jq -r '.data.name')
PARTITION=$(echo "$CONFIG" | jq -r '.data.parallelismConfig | to_entries[0].value')
JAR_ID=$(echo "$CONFIG" | jq -r '.data.jarId')
CONFIG_ID=$(echo "$CONFIG" | jq -r '.data.id')
MULTI_SQL=$(echo "$CONFIG" | jq -r '.data.multiSql // ""')
CLUSTER_ID=$(echo "$CONFIG" | jq -r '.data.clusterId')
OPERATOR_COUNT=$(echo "$CONFIG" | jq -r '.data.parallelismConfig | keys | length')

if [ "$PARTITION" = "null" ] || [ -z "$PARTITION" ]; then
    echo "错误：无法获取 partition 数量"
    exit 1
fi

echo "  任务名：$TASK_NAME"
echo "  Partition: $PARTITION"
echo "  算子数：$OPERATOR_COUNT"
echo "  JarId: $JAR_ID"

# 步骤 2: 生成优化配置
echo "[2/5] 生成优化配置..."

# 保存配置到临时文件
echo "$CONFIG" > /tmp/config_${TOPOLOGY_ID}.json

python3 << PYEOF
import json

topo_id = "$TOPOLOGY_ID"
partition = $PARTITION
operator_count = $OPERATOR_COUNT
jar_id = "$JAR_ID"
config_id = $CONFIG_ID
task_name = "$TASK_NAME"
cluster_id = $CLUSTER_ID

# 标准 simply-opt 配置
# 黄金法则:
# 1. kepler.worker.size = partition 数量 = parallelismConfig 所有值
# 2. job.worker.thread.number = 1
# 3. memory: 2G~6G (2147483648 ~ 6442450944)
# 4. kepler.output.odps.buffer.size: 60~200
OPT_CONFIG = {
    'kepler.worker.size': str(partition),
    'kepler.worker.memory.size': '4294967296',  # 4GB，在 2-6GB 范围内
    'worker.cpu.slot.num': '3',
    'kepler.output.odps.buffer.size': '120',  # 在 60-200 范围内
    'job.worker.thread.number': '1'  # 黄金法则：必须为 1
}
DELETE_KEYS = ['kepler.output.queue.capacity']

# 读取配置
with open(f'/tmp/config_{topo_id}.json') as f:
    resp = json.load(f)

d = resp.get('data', {})
old_config = d.get('keplerConfig', [])
new_config = []
changes = []

for c in old_config:
    key = c.get('key')
    old_val = c.get('value')
    
    if key in DELETE_KEYS:
        changes.append(('删除', key, old_val, '-'))
        continue
    
    if key in OPT_CONFIG:
        new_val = OPT_CONFIG[key]
        if str(old_val) != str(new_val):
            changes.append(('修改', key, old_val or '未设置', new_val))
            c['value'] = new_val
        new_config.append(c)
    else:
        new_config.append(c)

current_keys = {c.get('key') for c in new_config}
for key, value in OPT_CONFIG.items():
    if key not in current_keys:
        changes.append(('新增', key, '未设置', value))
        is_system = key in ['kepler.worker.size', 'kepler.worker.memory.size']
        new_config.append({"key": key, "value": value, "system": is_system})

parallelism = d.get('parallelismConfig', {})
new_parallelism = {k: partition for k in parallelism}

print("=" * 50)
print("Simply-Opt 变更计划")
print("=" * 50)
print()
print("[黄金法则检查]")
print(f"  ✓ kepler.worker.size = {partition} (与 Partition 一致)")
print(f"  ✓ parallelismConfig 所有算子 = {partition} (与 Partition 一致)")
print(f"  ✓ job.worker.thread.number = 1")
print(f"  ✓ worker.memory.size = 4GB (在 2-6GB 范围内)")
print(f"  ✓ odps.buffer.size = 120 (在 60-200 范围内)")
print()
print("[配置变更]")
for action, key, old, new in changes:
    if action == '删除':
        print(f"  [{action}] {key}")
    else:
        print(f"  [{action}] {key}: {old} -> {new}")
print(f"  [并行度] {len(parallelism)} 个算子全部设置为：{partition}")

request = {
    "id": config_id,
    "topologyId": topo_id,
    "multiSql": d.get('multiSql', ''),
    "keplerConfig": new_config,
    "jars": d.get('jars', []),
    "type": d.get('type', 'KEPLER'),
    "clusterId": str(cluster_id),
    "name": task_name,
    "comment": d.get('comment', ''),
    "bizGroupCode": d.get('bizGroupCode', ''),
    "parallelismConfig": new_parallelism,
    "jarId": str(jar_id),
    "baseline": d.get('baseline', 1),
    "jobType": d.get('jobType', 'SQL')
}

with open(f'/tmp/kepler_update_{topo_id}.json', 'w') as f:
    json.dump(request, f, ensure_ascii=False, indent=2)

print(f"\\n更新文件已生成：/tmp/kepler_update_{topo_id}.json")
PYEOF

# 步骤 3: 提交更新
echo "[3/5] 提交配置更新..."
UPDATE_RESULT=$(curl -s -X POST "${KEPLER_API}/sql/update" \
    -H "Content-Type: application/json" \
    -b "$COOKIE" \
    --connect-timeout 10 \
    -d "@/tmp/kepler_update_${TOPOLOGY_ID}.json")

if echo "$UPDATE_RESULT" | grep -q '"success":true'; then
    echo "  ✓ 配置更新成功"
else
    echo "  ✗ 配置更新失败：$UPDATE_RESULT"
    exit 1
fi

# 步骤 4: 等待
echo "[4/5] 等待 10 秒..."
sleep 10

# 步骤 5: 重启任务
echo "[5/5] 重启任务..."
RESTART_RESULT=$(curl -s -X POST "${KEPLER_API}/topology/${TOPOLOGY_ID}/ops/restart" \
    -H "Content-Type: application/json" \
    -H "endpoint: ui" \
    -b "$COOKIE" \
    -d '{}' \
    --connect-timeout 10)

if echo "$RESTART_RESULT" | grep -q '"success":true'; then
    echo "  ✓ 重启成功"
else
    echo "  重启结果：$RESTART_RESULT"
fi

echo ""
echo "═══════════════════════════════════════════════════════════"
echo "  优化完成！任务正在重启中..."
echo "═══════════════════════════════════════════════════════════"